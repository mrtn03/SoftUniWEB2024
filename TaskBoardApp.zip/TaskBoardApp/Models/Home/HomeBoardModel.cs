﻿namespace TaskBoardApp.Web.ViewModels.Home
{
    public class HomeBoardModel
    {
        public string BoardName { get; set; } = null!;
        public int TasksCount { get; set; }
    }
}