﻿namespace TaskBoardApp.Data.Models
{
    public class TaskBoardModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}